import pynof
import numpy as np

mol = pynof.molecule("""
0 2
Zn 0.0000 0.0000 0.00000
N 0.0000 0.0000 1.891
C 0.0000 0.0000 3.064
""")

p = pynof.param(mol,"def2-TZVPD")
p.ipnof = 7
p.optimizer = "L-BFGS-B"
p.set_ncwo(1)

p.RI = True
p.gpu = True
p.jit = False
p.threshl = 10**-4
p.threshe = 10**-5


p.title = "ZnNC-def2-TZVPD-1-hf"
p.autozeros()
E_min,C_min,gamma_min,fmiug0_min = pynof.compute_energy(mol,p,p.gradient,hfidr=True)

p.scaling=True
p.nzeros = -4

for i in range(5):
    #p.nzeros = i
    p.autozeros()
    gamma = np.random.rand(p.nv)
    p.title = "ZnNC-def2-TZVPD-1-"+str(i)
    E,C,gamma,fmiug0 = pynof.compute_energy(mol,p,p.gradient,C_min,gamma_min,fmiug0_min,hfidr=False,nofmp2=False)
    if(E<E_min):
        E_min = E
        C_min = C
        gamma_min = gamma
        fmiug0_min = fmiug0
    C = C_min
    C = C*(np.ones((p.nbf,p.nbf))+np.random.rand(p.nbf,p.nbf))
    fmiug0 = fmiug0_min
    fmiug0 = fmiug0*(np.ones((p.nbf))+np.random.rand(p.nbf))

p.title = "ZnNC-def2-TZVPD-1-best"
p.RI = False
p.autozeros()
E,C,gamma,fmiug0 = pynof.compute_energy(mol,p,p.gradient,C_min,gamma_min,fmiug0_min,hfidr=False,nofmp2=False)

print("Best Total NOF Energy " + str(E))

